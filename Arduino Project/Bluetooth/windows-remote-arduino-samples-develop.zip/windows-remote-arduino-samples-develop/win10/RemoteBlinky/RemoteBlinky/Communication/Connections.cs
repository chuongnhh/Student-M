using System.Collections.ObjectModel;

namespace Communication
{
    public class Connections : ObservableCollection<Connection>
    {
    }
}