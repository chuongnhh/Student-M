﻿// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF 
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A 
// PARTICULAR PURPOSE. 
// 
// Copyright (c) Microsoft Corporation. All rights reserved 
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Windows.UI.Popups;

using WindowsRobot.Common;
using ArduinoBluetooth.Connection;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace WindowsRobot.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ControlsView : Page
    {

        public ControlsView()
        {
            this.InitializeComponent();

            App.BluetoothManager.MessageReceived += BluetoothManager_MessageReceived;
            App.BluetoothManager.ExceptionOccured += BluetoothManager_ExceptionOccured;
        }

        protected override void OnNavigatedFrom(Windows.UI.Xaml.Navigation.NavigationEventArgs e)
        {
            App.BluetoothManager.Disconnect(); // clean up the mess
        }

        private async void BluetoothManager_ExceptionOccured(object sender, Exception ex)
        {
            var md = new MessageDialog(ex.Message, "We've got a problem with bluetooth...");
            md.Commands.Add(new UICommand("Doh!"));
            md.DefaultCommandIndex = 0;
            var result = await md.ShowAsync();
        }

        private void BluetoothManager_MessageReceived(object sender, string message)
        {
            System.Diagnostics.Debug.WriteLine(message);
        }
        
       
        
        private async void Connect_Click(object sender, RoutedEventArgs e)
        {
            //ask the user to connect
            await App.BluetoothManager.EnumerateDevicesAsync(GetElementRect((FrameworkElement)sender));
        }
        
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            //cancel current connection attempts
            App.BluetoothManager.AbortConnection();
        }
        
        private void Disconnect_Click(object sender, RoutedEventArgs e)
        {
            //disconnect the connection
            App.BluetoothManager.Disconnect();
        }
       
        /// <summary>
        /// Kick the application off
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Start_Click(object sender, RoutedEventArgs e)
        {
            //ControlGrid.Visibility = 
        }

        #region GUI Dropdown
        public static Rect GetElementRect(FrameworkElement element)
        {
            GeneralTransform buttonTransform = element.TransformToVisual(null);
            Point point = buttonTransform.TransformPoint(new Point(0, 0));
            return new Rect(point, new Size(element.ActualWidth, element.ActualHeight));
        }
        #endregion

        private void btnDirection_Click(object sender, RoutedEventArgs e)
        {
            Button _button = (Button)sender;
            string direction = _button.CommandParameter.ToString();

            SendMessage(direction);
        }

        private async void SendMessage(string direction)
        {
            string cmd = direction.ToUpper().Remove(1, direction.Length-1);
            var res = await App.BluetoothManager.SendMessageAsync(cmd);
        }

    }
}
