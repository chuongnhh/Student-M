THIS IS DESIGNED FOR MICROSOFT VISUAL STUDIO EXPRESS

MUST HAVE AN ARDUINO + WINDOWS PHONE 8 FOR SUCCESSFUL TEST

Twitter: @LanceSeidman
Blog: http://lance.compulsivetech.biz
Web Show: http://youtube.com/TechMeShow